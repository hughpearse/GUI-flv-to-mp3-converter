#!/bin/bash

java Main
